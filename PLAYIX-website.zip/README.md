# PLAYIX Website — deployable starter

This is a static mobile-first PWA website. It includes:
- Responsive PLAYIX interface
- Save link, favorites, saved library, search, remove and export
- URL validation and common platform recognition
- Light/dark theme
- PWA manifest, icon and basic service worker
- Privacy, terms, copyright and support starter pages
- Admin information page (not a live secure admin console)

## Run / deploy
No build step is required. Upload these files to a GitHub repository and deploy using Vercel (Other framework / static) or Netlify. Make sure `index.html` is the root entry point. PWA install requires HTTPS.

## Important limits
- Guest library uses localStorage on the current browser only.
- Firebase Auth, cloud sync and secure admin backend are not connected in this static package.
- Direct social video downloading and scraping are not implemented. Download/Both choices explain that downloads are not enabled. Only add provider integrations that explicitly authorize the media and comply with source terms, copyright and privacy.
- Legal pages are starter templates, not legal advice. Replace contact placeholders and make the policies accurate before launch.
